package com.livefront.bridgesample.scenario.activity

import android.os.Bundle
import com.livefront.bridgesample.R
import com.livefront.bridgesample.base.BridgeBaseActivity

class SuccessActivity : BridgeBaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_success)
    }
}
