package fr.efrei.reagency.viewmodel;

import java.util.List;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import fr.efrei.reagency.bo.Property;
import fr.efrei.reagency.repository.PropertyRepository;

public final class PropertiesActivityViewModel
        extends AndroidViewModel
{

    public enum OrderState
    {
        Order, NotOrder
    }

    public MutableLiveData<List<Property>> properties = new MutableLiveData<>();

    private OrderState currentOrderState = OrderState.NotOrder;

    public PropertiesActivityViewModel(@NonNull Application application)
    {
        super(application);
    }

    public void updateOrder(OrderState orderState)
    {
        currentOrderState = orderState;
        loadProperties();
    }

    public void loadProperties()
    {
        properties.postValue(currentOrderState == OrderState.NotOrder ? PropertyRepository.getInstance(getApplication()).getProperties() : PropertyRepository.getInstance(getApplication()).sortPropertiesByName());
    }

}
